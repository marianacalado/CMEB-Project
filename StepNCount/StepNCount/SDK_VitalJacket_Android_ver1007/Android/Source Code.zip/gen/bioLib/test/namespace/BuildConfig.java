/** Automatically generated file. DO NOT MODIFY */
package bioLib.test.namespace;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}